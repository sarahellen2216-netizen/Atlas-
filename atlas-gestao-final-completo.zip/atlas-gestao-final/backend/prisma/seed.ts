import { PrismaClient, Perfil } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const senha = await bcrypt.hash("Admin@123", 10);
  await prisma.usuario.upsert({
    where: { email: "admin@atlasgestao.com" },
    update: {},
    create: {
      nome: "Administrador",
      email: "admin@atlasgestao.com",
      senha,
      perfil: Perfil.ADMINISTRADOR
    }
  });
  console.log("Usuário administrador criado.");
}

main().finally(() => prisma.$disconnect());
