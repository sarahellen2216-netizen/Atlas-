import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import multer from "multer";
import path from "path";
import fs from "fs";
import PDFDocument from "pdfkit";
import ExcelJS from "exceljs";
import { PrismaClient, Perfil } from "@prisma/client";

dotenv.config();
const prisma = new PrismaClient();
const app = express();
const PORT = Number(process.env.PORT || 3333);
const JWT_SECRET = process.env.JWT_SECRET || "change-me";
const uploadDir = path.resolve(process.env.UPLOAD_DIR || "./uploads");
fs.mkdirSync(uploadDir, { recursive: true });

app.use(cors({ origin: process.env.CORS_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(uploadDir));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, `${Date.now()}-${safe}`);
  }
});
const upload = multer({ storage });

type AuthReq = express.Request & { user?: { id: string; perfil: Perfil } };
const asyncRoute = (fn: any) => (req: any, res: any, next: any) => Promise.resolve(fn(req,res,next)).catch(next);

function auth(req: AuthReq, res: express.Response, next: express.NextFunction) {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) return res.status(401).json({ message: "Não autenticado" });
  try { req.user = jwt.verify(token, JWT_SECRET) as any; next(); }
  catch { res.status(401).json({ message: "Token inválido ou expirado" }); }
}
function roles(...allowed: Perfil[]) {
  return (req: AuthReq, res: express.Response, next: express.NextFunction) => {
    if (!req.user || !allowed.includes(req.user.perfil)) return res.status(403).json({ message: "Sem permissão" });
    next();
  };
}
const writeRoles = [Perfil.ADMINISTRADOR, Perfil.SUPERVISOR];
const inspectionRoles = [...writeRoles, Perfil.INSPETOR];
const auditRoles = [...writeRoles, Perfil.AUDITOR];

app.get("/api/health", (_req,res)=>res.json({status:"ok", sistema:"Atlas Gestão"}));

app.post("/api/auth/login", asyncRoute(async (req,res)=>{
  const {email,senha}=req.body;
  const user=await prisma.usuario.findUnique({where:{email}});
  if(!user || user.status!=="ATIVO" || !(await bcrypt.compare(senha,user.senha)))
    return res.status(401).json({message:"E-mail ou senha inválidos"});
  const token=jwt.sign({id:user.id,perfil:user.perfil},JWT_SECRET,{expiresIn:"8h"});
  res.json({token,usuario:{id:user.id,nome:user.nome,email:user.email,perfil:user.perfil}});
}));

app.get("/api/dashboard",auth,asyncRoute(async (_req,res)=>{
  const [inspecoes,ncAbertas,ncTotal,acoesAbertas,acoesConcluidas,auditorias,documentos,conformes,reprovados]=await Promise.all([
    prisma.inspecao.count(),
    prisma.naoConformidade.count({where:{status:{not:"FECHADA"}}}),
    prisma.naoConformidade.count(),
    prisma.acaoCorretiva.count({where:{status:{in:["ABERTA","EM_ANDAMENTO","ATRASADA"]}}}),
    prisma.acaoCorretiva.count({where:{status:"CONCLUIDA"}}),
    prisma.auditoria.count(),
    prisma.documento.count(),
    prisma.inspecao.count({where:{resultado:"CONFORME"}}),
    prisma.inspecao.count({where:{resultado:"NAO_CONFORME"}})
  ]);
  const taxa=inspecoes?Math.round(conformes/inspecoes*100):0;
  const months=await prisma.inspecao.findMany({select:{data:true,resultado:true},orderBy:{data:"asc"}});
  const byMonth:any={};
  months.forEach(x=>{const k=x.data.toISOString().slice(0,7); byMonth[k]??={total:0,conformes:0}; byMonth[k].total++; if(x.resultado==="CONFORME")byMonth[k].conformes++;});
  const sectors=await prisma.auditoria.groupBy({by:["setor"],_count:{_all:true}});
  res.json({cards:{inspecoes,ncAbertas,ncTotal,acoesAbertas,acoesConcluidas,auditorias,documentos,taxa,conformes,reprovados},charts:{inspecoesPorMes:Object.entries(byMonth).map(([mes,v]:any)=>({mes,total:v.total,conformes:v.conformes})),auditoriasPorSetor:sectors.map(x=>({setor:x.setor,total:x._count._all}))}});
}));

const crud = (name:string, model:any, allowed:Perfil[], include:any={}) => {
  app.get(`/api/${name}`, auth, asyncRoute(async (_req,res)=>res.json(await model.findMany({include,orderBy:{data:"desc"}})));
  app.get(`/api/${name}/:id`, auth, asyncRoute(async (req,res)=>res.json(await model.findUnique({where:{id:req.params.id},include}))));
  app.post(`/api/${name}`, auth, roles(...allowed), asyncRoute(async(req,res)=>res.status(201).json(await model.create({data:req.body}))));
  app.put(`/api/${name}/:id`, auth, roles(...allowed), asyncRoute(async(req,res)=>res.json(await model.update({where:{id:req.params.id},data:req.body}))));
  app.delete(`/api/${name}/:id`, auth, roles(...allowed), asyncRoute(async(req,res)=>{await model.delete({where:{id:req.params.id}});res.status(204).send();}));
};

crud("inspecoes",prisma.inspecao,inspectionRoles,{responsavel:{select:{id:true,nome:true}},naoConformidade:true});
crud("nao-conformidades",prisma.naoConformidade,inspectionRoles,{responsavel:{select:{id:true,nome:true}},acoes:true});
crud("acoes-corretivas",prisma.acaoCorretiva,writeRoles,{responsavel:{select:{id:true,nome:true}},naoConformidade:true});
crud("auditorias",prisma.auditoria,auditRoles,{auditor:{select:{id:true,nome:true}}});
crud("documentos",prisma.documento,writeRoles,{responsavel:{select:{id:true,nome:true}},revisoes:true});

app.post("/api/documentos/upload",auth,roles(...writeRoles),upload.single("arquivo"),asyncRoute(async(req,res)=>{
  if(!req.file)return res.status(400).json({message:"Arquivo não enviado"});
  const data={...req.body,data:new Date(req.body.data||Date.now()),arquivo:`/uploads/${req.file.filename}`};
  res.status(201).json(await prisma.documento.create({data}));
}));

app.post("/api/documentos/:id/revisoes",auth,roles(...writeRoles),upload.single("arquivo"),asyncRoute(async(req,res)=>{
  const doc=await prisma.documento.findUnique({where:{id:req.params.id}});
  if(!doc)return res.status(404).json({message:"Documento não encontrado"});
  const arquivo=req.file?`/uploads/${req.file.filename}`:doc.arquivo;
  const revision=await prisma.revisaoDocumento.create({data:{documentoId:doc.id,revisao:req.body.revisao,arquivo,observacao:req.body.observacao}});
  await prisma.documento.update({where:{id:doc.id},data:{revisao:req.body.revisao,arquivo}});
  res.status(201).json(revision);
}));

app.get("/api/usuarios",auth,roles(Perfil.ADMINISTRADOR),asyncRoute(async(_req,res)=>{
  res.json(await prisma.usuario.findMany({select:{id:true,nome:true,email:true,perfil:true,status:true,criadoEm:true},orderBy:{nome:"asc"}}));
}));
app.post("/api/usuarios",auth,roles(Perfil.ADMINISTRADOR),asyncRoute(async(req,res)=>{
  const senha=await bcrypt.hash(req.body.senha,10);
  const u=await prisma.usuario.create({data:{nome:req.body.nome,email:req.body.email,senha,perfil:req.body.perfil,status:req.body.status||"ATIVO"}});
  res.status(201).json({id:u.id,nome:u.nome,email:u.email,perfil:u.perfil,status:u.status});
}));
app.put("/api/usuarios/:id",auth,roles(Perfil.ADMINISTRADOR),asyncRoute(async(req,res)=>{
  const data:any={nome:req.body.nome,email:req.body.email,perfil:req.body.perfil,status:req.body.status};
  if(req.body.senha)data.senha=await bcrypt.hash(req.body.senha,10);
  res.json(await prisma.usuario.update({where:{id:req.params.id},data,select:{id:true,nome:true,email:true,perfil:true,status:true}}));
}));
app.delete("/api/usuarios/:id",auth,roles(Perfil.ADMINISTRADOR),asyncRoute(async(req,res)=>{await prisma.usuario.delete({where:{id:req.params.id}});res.status(204).send();}));


async function reportRows(tipo:string){
  if(tipo==="inspecoes") return await prisma.inspecao.findMany({include:{responsavel:{select:{nome:true}}}});
  if(tipo==="auditorias") return await prisma.auditoria.findMany({include:{auditor:{select:{nome:true}}}});
  if(tipo==="nao-conformidades") return await prisma.naoConformidade.findMany({include:{responsavel:{select:{nome:true}}}});
  if(tipo==="acoes-corretivas") return await prisma.acaoCorretiva.findMany({include:{responsavel:{select:{nome:true}}}});
  if(tipo==="documentos") return await prisma.documento.findMany({include:{responsavel:{select:{nome:true}}}});
  return [];
}

app.get("/api/relatorios/:tipo/pdf", auth, asyncRoute(async(req,res)=>{
  const rows:any[]=await reportRows(req.params.tipo);
  res.setHeader("Content-Type","application/pdf");
  res.setHeader("Content-Disposition",`attachment; filename="atlas-${req.params.tipo}.pdf"`);
  const doc=new PDFDocument({margin:40});
  doc.pipe(res);
  doc.fontSize(20).text("Atlas Gestão");
  doc.fontSize(13).text(`Relatório de ${req.params.tipo}`);
  doc.fontSize(9).fillColor("#64748b").text(`Gerado em ${new Date().toLocaleString("pt-BR")}`);
  doc.moveDown();
  rows.forEach((r,i)=>{
    const code=r.codigo||r.numero||r.nome||r.id;
    const status=r.status||r.resultado||r.revisao||"-";
    const detail=r.descricao||r.produto||r.planoAcao||r.setor||"-";
    doc.fillColor("#1f2937").fontSize(10).text(`${i+1}. ${code} | ${status}`);
    doc.fontSize(9).fillColor("#475569").text(String(detail).slice(0,220));
    doc.moveDown(.6);
    if(doc.y>730)doc.addPage();
  });
  doc.end();
}));

app.get("/api/relatorios/:tipo/excel", auth, asyncRoute(async(req,res)=>{
  const rows:any[]=await reportRows(req.params.tipo);
  const wb=new ExcelJS.Workbook();
  const ws=wb.addWorksheet("Relatório");
  ws.columns=[
    {header:"Código/Número",key:"codigo",width:24},
    {header:"Descrição/Produto",key:"descricao",width:42},
    {header:"Status/Resultado",key:"status",width:25},
    {header:"Data",key:"data",width:18},
    {header:"Responsável",key:"responsavel",width:28}
  ];
  rows.forEach(r=>ws.addRow({
    codigo:r.codigo||r.numero||r.nome||r.id,
    descricao:r.descricao||r.produto||r.planoAcao||r.setor||"-",
    status:r.status||r.resultado||r.revisao||"-",
    data:r.data?new Date(r.data).toLocaleDateString("pt-BR"):"",
    responsavel:r.responsavel?.nome||r.auditor?.nome||""
  }));
  ws.getRow(1).font={bold:true};
  ws.autoFilter={from:"A1",to:"E1"};
  res.setHeader("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition",`attachment; filename="atlas-${req.params.tipo}.xlsx"`);
  await wb.xlsx.write(res); res.end();
}));

app.get("/api/relatorios/:tipo",auth,asyncRoute(async(req,res)=>{
  const tipo=req.params.tipo;
  const data:any={geradoEm:new Date(),tipo};
  if(tipo==="inspecoes")data.registros=await prisma.inspecao.findMany({include:{responsavel:{select:{nome:true}}}});
  else if(tipo==="auditorias")data.registros=await prisma.auditoria.findMany({include:{auditor:{select:{nome:true}}}});
  else if(tipo==="nao-conformidades")data.registros=await prisma.naoConformidade.findMany({include:{responsavel:{select:{nome:true}}}});
  else if(tipo==="acoes-corretivas")data.registros=await prisma.acaoCorretiva.findMany({include:{responsavel:{select:{nome:true}}}});
  else data.dashboard=await prisma.inspecao.count();
  res.json(data);
}));

app.use((err:any,_req:any,res:any,_next:any)=>{console.error(err);res.status(500).json({message:err.message||"Erro interno"});});
app.listen(PORT,()=>console.log(`Atlas Gestão API: http://localhost:${PORT}`));
