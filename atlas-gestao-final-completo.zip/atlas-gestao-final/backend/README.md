# Atlas Gestão — Backend

## Instalação
```bash
npm install
cp .env.example .env
npx prisma generate
npx prisma migrate dev --name init
npm run seed
npm run dev
```

API: http://localhost:3333

## Perfis
- ADMINISTRADOR: acesso completo
- SUPERVISOR: operações da qualidade
- INSPETOR: inspeções e NCs
- AUDITOR: auditorias
- VISUALIZADOR: leitura
