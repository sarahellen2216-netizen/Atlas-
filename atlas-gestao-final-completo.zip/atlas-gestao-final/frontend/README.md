# Atlas Gestão — Frontend
```bash
npm install
npm run dev
```
Abra http://localhost:5173
