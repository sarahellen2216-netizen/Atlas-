import { useEffect, useMemo, useState } from "react";
import { Routes, Route, Navigate, Link, useLocation, useNavigate } from "react-router-dom";
import { api } from "./services/api";
import {
  LayoutDashboard, ClipboardCheck, AlertTriangle, Wrench, SearchCheck, FileText,
  BarChart3, Settings, Users, LogOut, Menu, Plus, Moon, Sun, Pencil, Trash2,
  Search, Download, X, CheckCircle2, Clock3, XCircle
} from "lucide-react";

type User={id:string;nome:string;email:string;perfil:string};
const menu:any[]=[
 ["/","Dashboard",LayoutDashboard],[ "/inspecoes","Inspeções",ClipboardCheck],
 ["/nao-conformidades","Não Conformidades",AlertTriangle],[ "/acoes-corretivas","Ações Corretivas",Wrench],
 ["/auditorias","Auditorias",SearchCheck],[ "/documentos","Documentos",FileText],
 ["/relatorios","Relatórios",BarChart3],[ "/usuarios","Usuários",Users],[ "/configuracoes","Configurações",Settings]
];

function Login({onLogin}:{onLogin:(u:User)=>void}){
 const [email,setEmail]=useState("admin@atlasgestao.com"),[senha,setSenha]=useState("Admin@123"),[erro,setErro]=useState("");
 const nav=useNavigate();
 async function submit(e:any){e.preventDefault();try{const r=await api.post("/auth/login",{email,senha});localStorage.setItem("atlas_token",r.data.token);localStorage.setItem("atlas_user",JSON.stringify(r.data.usuario));onLogin(r.data.usuario);nav("/")}catch{setErro("E-mail ou senha inválidos.")}}
 return <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-700 to-blue-500 p-5"><form onSubmit={submit} className="bg-white w-full max-w-md rounded-2xl p-8 shadow-2xl"><div className="flex items-center gap-3 mb-8"><div className="bg-blue-600 text-white p-3 rounded-xl text-xl font-bold">A</div><div><h1 className="text-2xl font-bold">Atlas Gestão</h1><p className="text-sm text-slate-500">Garantia da Qualidade</p></div></div><h2 className="text-xl font-bold">Acesso ao sistema</h2><p className="text-slate-500 mb-6">Gestão Inteligente da Qualidade para Empresas Modernas</p><Input label="E-mail" value={email} onChange={setEmail}/><Input label="Senha" type="password" value={senha} onChange={setSenha}/>{erro&&<p className="text-red-600 text-sm mb-3">{erro}</p>}<button className="w-full bg-blue-600 text-white p-3 rounded-lg font-semibold">Entrar</button><p className="text-xs text-center text-slate-400 mt-4">admin@atlasgestao.com / Admin@123</p></form></div>
}

function Input({label,value,onChange,type="text",placeholder=""}:{label:string;value:any;onChange:(v:string)=>void;type?:string;placeholder?:string}){
 return <label className="block text-sm font-medium mb-4">{label}<input type={type} value={value??""} placeholder={placeholder} onChange={e=>onChange(e.target.value)} className="mt-1 w-full border border-slate-200 rounded-lg p-2.5 outline-none focus:ring-2 focus:ring-blue-500"/></label>
}
function Select({label,value,onChange,options}:{label:string;value:any;onChange:(v:string)=>void;options:string[]}){
 return <label className="block text-sm font-medium mb-4">{label}<select value={value??""} onChange={e=>onChange(e.target.value)} className="mt-1 w-full border rounded-lg p-2.5 bg-white">{options.map(o=><option key={o}>{o}</option>)}</select></label>
}
function Modal({title,onClose,children}:{title:string;onClose:()=>void;children:any}){
 return <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4"><div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-auto"><div className="p-5 border-b flex justify-between items-center"><h2 className="font-bold text-lg">{title}</h2><button onClick={onClose}><X/></button></div><div className="p-5">{children}</div></div></div>
}
function Layout({user,onLogout,children}:{user:User;onLogout:()=>void;children:any}){
 const [open,setOpen]=useState(false),[dark,setDark]=useState(false); const loc=useLocation();
 useEffect(()=>document.documentElement.classList.toggle("dark",dark),[dark]);
 return <div className="min-h-screen bg-slate-50 dark:bg-slate-950 dark:text-white"><aside className={`fixed z-40 inset-y-0 left-0 w-64 bg-white dark:bg-slate-900 border-r transition-transform ${open?"translate-x-0":"-translate-x-full"} md:translate-x-0`}><div className="p-5 border-b flex items-center gap-3"><div className="bg-blue-600 text-white p-2 rounded-lg font-bold">A</div><div><b>Atlas Gestão</b><p className="text-xs text-slate-400">Garantia da Qualidade</p></div></div><nav className="p-3 space-y-1">{menu.map(([p,l,I])=><Link key={p} to={p} onClick={()=>setOpen(false)} className={`flex gap-3 items-center p-3 rounded-lg text-sm ${loc.pathname===p?"bg-blue-50 text-blue-700":"text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"}`}><I size={18}/>{l}</Link>)}</nav><div className="absolute bottom-0 p-4 border-t w-full"><b className="text-sm">{user.nome}</b><p className="text-xs text-slate-400 mb-2">{user.perfil}</p><button onClick={onLogout} className="text-red-600 flex gap-2 text-sm"><LogOut size={17}/>Sair</button></div></aside><div className="md:ml-64"><header className="h-16 sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 border-b flex justify-between items-center px-4 md:px-7"><button className="md:hidden" onClick={()=>setOpen(!open)}><Menu/></button><b>Sistema de Garantia da Qualidade</b><button onClick={()=>setDark(!dark)}>{dark?<Sun/>:<Moon/>}</button></header><main className="p-4 md:p-7"><Notifications/>{children}</main></div></div>
}

function Dashboard(){
 const [d,setD]=useState<any>(null); useEffect(()=>{api.get("/dashboard").then(r=>setD(r.data))},[]);
 if(!d)return <Loading/>;
 const c=d.cards;
 const cards=[["Inspeções realizadas",c.inspecoes,ClipboardCheck,"text-blue-600"],["NCs abertas",c.ncAbertas,AlertTriangle,"text-red-600"],["Ações abertas",c.acoesAbertas,Wrench,"text-amber-600"],["Auditorias",c.auditorias,SearchCheck,"text-green-600"],["Documentos ativos",c.documentos,FileText,"text-purple-600"],["Taxa de conformidade",`${c.taxa}%`,CheckCircle2,"text-green-600"]];
 return <><PageTitle title="Dashboard" subtitle="Visão geral dos indicadores da qualidade."/><div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">{cards.map(([t,v,I,col])=><div className="bg-white dark:bg-slate-900 border rounded-xl p-5 flex justify-between" key={t as string}><div><span className="text-sm text-slate-500">{t}</span><div className="text-3xl font-bold mt-2">{v}</div></div><I className={col as string}/></div>)}</div><div className="grid xl:grid-cols-2 gap-5 mt-5"><div className="bg-white dark:bg-slate-900 border rounded-xl p-5"><h2 className="font-bold mb-4">Inspeções por mês</h2>{d.charts.inspecoesPorMes.length?<div className="space-y-3">{d.charts.inspecoesPorMes.slice(-8).map((x:any)=><div key={x.mes}><div className="flex justify-between text-sm"><span>{x.mes}</span><b>{x.total} inspeções / {x.conformes} conformes</b></div><div className="h-3 bg-slate-100 rounded-full mt-1"><div className="h-3 bg-blue-600 rounded-full" style={{width:`${Math.max(5,x.total?x.conformes/x.total*100:0)}%`}}/></div></div>)}</div>:<Empty text="Ainda não existem dados."/>}</div><div className="bg-white dark:bg-slate-900 border rounded-xl p-5"><h2 className="font-bold mb-4">Indicadores rápidos</h2><div className="grid grid-cols-2 gap-3"><Metric title="Produtos aprovados" value={c.conformes} icon={<CheckCircle2 className="text-green-600"/>}/><Metric title="Produtos reprovados" value={c.reprovados} icon={<XCircle className="text-red-600"/>}/><Metric title="Ações concluídas" value={c.acoesConcluidas} icon={<CheckCircle2 className="text-blue-600"/>}/><Metric title="NCs totais" value={c.ncTotal} icon={<AlertTriangle className="text-amber-600"/>}/></div></div></div></>
}
function Metric({title,value,icon}:{title:string;value:number;icon:any}){return <div className="border rounded-lg p-4"><div>{icon}</div><b className="text-2xl">{value}</b><p className="text-xs text-slate-500">{title}</p></div>}
function PageTitle({title,subtitle,action}:{title:string;subtitle?:string;action?:any}){return <div className="flex justify-between items-center mb-6"><div><h1 className="text-2xl font-bold">{title}</h1>{subtitle&&<p className="text-slate-500">{subtitle}</p>}</div>{action}</div>}
function Loading(){return <div className="p-12 text-center text-slate-400">Carregando...</div>}
function Empty({text="Nenhum registro encontrado."}){return <div className="p-12 text-center text-slate-400">{text}</div>}

const configs:any={
 inspecoes:{title:"Inspeções",desc:"Controle de inspeções, lotes, produtos e resultados.",endpoint:"/inspecoes",fields:[["codigo","Código"],["produto","Produto"],["lote","Lote"],["local","Local"],["tipo","Tipo de inspeção"]],enums:{resultado:["CONFORME","NAO_CONFORME"]}},
 "nao-conformidades":{title:"Não Conformidades",desc:"Registro e tratamento das ocorrências da qualidade.",endpoint:"/nao-conformidades",fields:[["codigo","Código"],["produto","Produto"],["processo","Processo"],["descricao","Descrição"],["categoria","Categoria"]],enums:{gravidade:["BAIXA","MEDIA","ALTA","CRITICA"],status:["ABERTA","EM_ANALISE","EM_ANDAMENTO","RESOLVIDA","FECHADA"]}},
 "acoes-corretivas":{title:"Ações Corretivas",desc:"Planos de ação, responsáveis e prazos.",endpoint:"/acoes-corretivas",fields:[["numero","Número"],["naoConformidadeId","NC relacionada"],["planoAcao","Plano de ação"],["prazo","Prazo"]],enums:{status:["ABERTA","EM_ANDAMENTO","CONCLUIDA","ATRASADA"]}},
 auditorias:{title:"Auditorias",desc:"Auditorias internas, checklists e resultados.",endpoint:"/auditorias",fields:[["codigo","Código"],["setor","Setor"],["tipo","Tipo"],["checklist","Checklist"]],enums:{resultado:["CONFORME","PARCIALMENTE_CONFORME","NAO_CONFORME"]}}
};

function CrudPage({type}:{type:keyof typeof configs}){
 const cfg=configs[type] as any; const [items,setItems]=useState<any[]>([]),[loading,setLoading]=useState(true),[modal,setModal]=useState(false),[editing,setEditing]=useState<any>(null),[q,setQ]=useState("");
 async function load(){setLoading(true);try{setItems((await api.get(cfg.endpoint)).data)}finally{setLoading(false)}} useEffect(()=>{load()},[]);
 const filtered=useMemo(()=>items.filter(i=>JSON.stringify(i).toLowerCase().includes(q.toLowerCase())),[items,q]);
 async function save(data:any){if(editing)await api.put(`${cfg.endpoint}/${editing.id}`,data);else await api.post(cfg.endpoint,data);setModal(false);setEditing(null);load()}
 async function del(id:string){if(confirm("Excluir este registro?")){await api.delete(`${cfg.endpoint}/${id}`);load()}}
 return <><PageTitle title={cfg.title} subtitle={cfg.desc} action={<button onClick={()=>{setEditing(null);setModal(true)}} className="bg-blue-600 text-white px-4 py-2 rounded-lg flex gap-2"><Plus size={17}/>Novo</button>}/><div className="bg-white dark:bg-slate-900 border rounded-xl overflow-hidden"><div className="p-4 border-b flex gap-2"><div className="relative max-w-md w-full"><Search className="absolute left-3 top-2.5 text-slate-400" size={18}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Pesquisar..." className="w-full border rounded-lg p-2 pl-9"/></div></div>{loading?<Loading/>:filtered.length===0?<Empty/>:<div className="overflow-auto"><table className="w-full text-sm"><thead className="bg-slate-50 dark:bg-slate-800"><tr><th className="p-3 text-left">Código/Número</th><th className="p-3 text-left">Descrição</th><th className="p-3 text-left">Data/Prazo</th><th className="p-3 text-left">Status/Resultado</th><th className="p-3 text-right">Ações</th></tr></thead><tbody>{filtered.map(i=><tr className="border-t" key={i.id}><td className="p-3 font-medium">{i.codigo||i.numero||"-"}</td><td className="p-3">{i.descricao||i.produto||i.planoAcao||i.setor||"-"}</td><td className="p-3">{i.data?new Date(i.data).toLocaleDateString("pt-BR"):i.prazo?new Date(i.prazo).toLocaleDateString("pt-BR"):"-"}</td><td className="p-3">{i.status||i.resultado||"-"}</td><td className="p-3 flex justify-end gap-2"><button onClick={()=>{setEditing(i);setModal(true)}} className="p-2 border rounded"><Pencil size={16}/></button><button onClick={()=>del(i.id)} className="p-2 border rounded text-red-600"><Trash2 size={16}/></button></td></tr>)}</tbody></table></div>}</div>{modal&&<CrudModal cfg={cfg} item={editing} onClose={()=>setModal(false)} onSave={save}/>}</>
}

function CrudModal({cfg,item,onClose,onSave}:{cfg:any;item:any;onClose:()=>void;onSave:(x:any)=>void}){
 const [d,setD]=useState<any>(item||{resultado:cfg.enums?.resultado?.[0],gravidade:cfg.enums?.gravidade?.[0],status:cfg.enums?.status?.[0]});
 const set=(k:string,v:any)=>setD((x:any)=>({...x,[k]:v}));
 return <Modal title={`${item?"Editar":"Novo"} ${cfg.title}`} onClose={onClose}><div className="grid md:grid-cols-2 gap-3">{cfg.fields.map(([k,l]:any)=><div key={k} className={k==="descricao"||k==="planoAcao"||k==="checklist"?"md:col-span-2":""}><Input label={l} value={d[k]||""} onChange={v=>set(k,v)}/></div>)}{Object.entries(cfg.enums||{}).map(([k,opts]:any)=><Select key={k} label={k==="status"?"Status":k==="resultado"?"Resultado":"Gravidade"} value={d[k]||opts[0]} onChange={v=>set(k,v)} options={opts}/>)}</div><div className="flex justify-end gap-2"><button onClick={onClose} className="border px-4 py-2 rounded-lg">Cancelar</button><button onClick={()=>onSave(d)} className="bg-blue-600 text-white px-4 py-2 rounded-lg">Salvar</button></div></Modal>
}

function Documents(){
 const [items,setItems]=useState<any[]>([]),[modal,setModal]=useState(false),[file,setFile]=useState<File|null>(null),[d,setD]=useState<any>({tipo:"POP",revisao:"00"});
 async function load(){setItems((await api.get("/documentos")).data)} useEffect(()=>{load()},[]);
 async function save(e:any){e.preventDefault();const fd=new FormData();Object.entries(d).forEach(([k,v])=>fd.append(k,String(v)));if(file)fd.append("arquivo",file);await api.post("/documentos/upload",fd);setModal(false);setFile(null);setD({tipo:"POP",revisao:"00"});load()}
 return <><PageTitle title="Documentos" subtitle="Controle documental, arquivos e histórico de revisões." action={<button onClick={()=>setModal(true)} className="bg-blue-600 text-white px-4 py-2 rounded-lg flex gap-2"><Plus size={17}/>Novo documento</button>}/><div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{items.map(x=><div className="bg-white dark:bg-slate-900 border rounded-xl p-5" key={x.id}><div className="flex justify-between"><FileText className="text-blue-600"/><span className="text-xs bg-slate-100 px-2 py-1 rounded">{x.revisao}</span></div><h3 className="font-bold mt-4">{x.nome}</h3><p className="text-sm text-slate-500">{x.codigo} · {x.tipo}</p>{x.arquivo&&<a className="text-blue-600 text-sm inline-flex gap-2 mt-4" href={`http://localhost:3333${x.arquivo}`} target="_blank"><Download size={16}/>Baixar arquivo</a>}<p className="text-xs text-slate-400 mt-3">{x.revisoes?.length||0} revisão(ões)</p></div>)}{!items.length&&<div className="col-span-full"><Empty/></div>}</div>{modal&&<Modal title="Novo documento" onClose={()=>setModal(false)}><form onSubmit={save}><Input label="Código" value={d.codigo} onChange={v=>setD({...d,codigo:v})}/><Input label="Nome" value={d.nome} onChange={v=>setD({...d,nome:v})}/><Select label="Tipo" value={d.tipo} onChange={v=>setD({...d,tipo:v})} options={["POP","INSTRUCAO_TRABALHO","PROCEDIMENTO","FORMULARIO","MANUAL"]}/><Input label="Revisão" value={d.revisao} onChange={v=>setD({...d,revisao:v})}/><Input label="Responsável (ID)" value={d.responsavelId} onChange={v=>setD({...d,responsavelId:v})}/><input required type="file" onChange={e=>setFile(e.target.files?.[0]||null)} className="mb-5"/><button className="bg-blue-600 text-white px-4 py-2 rounded-lg">Enviar documento</button></form></Modal>}</>
}

function UsersPage(){
 const [items,setItems]=useState<any[]>([]),[modal,setModal]=useState(false),[d,setD]=useState<any>({perfil:"VISUALIZADOR",status:"ATIVO"});
 const load=()=>api.get("/usuarios").then(r=>setItems(r.data));useEffect(()=>{load()},[]);
 async function save(e:any){e.preventDefault();await api.post("/usuarios",d);setModal(false);setD({perfil:"VISUALIZADOR",status:"ATIVO"});load()}
 return <><PageTitle title="Usuários" subtitle="Controle de acesso e permissões por perfil." action={<button onClick={()=>setModal(true)} className="bg-blue-600 text-white px-4 py-2 rounded-lg flex gap-2"><Plus size={17}/>Novo usuário</button>}/><div className="bg-white dark:bg-slate-900 border rounded-xl overflow-auto"><table className="w-full text-sm"><thead className="bg-slate-50"><tr><th className="p-3 text-left">Nome</th><th className="p-3 text-left">E-mail</th><th className="p-3 text-left">Perfil</th><th className="p-3 text-left">Status</th></tr></thead><tbody>{items.map(x=><tr className="border-t" key={x.id}><td className="p-3">{x.nome}</td><td className="p-3">{x.email}</td><td className="p-3">{x.perfil}</td><td className="p-3">{x.status}</td></tr>)}</tbody></table></div>{modal&&<Modal title="Novo usuário" onClose={()=>setModal(false)}><form onSubmit={save}><Input label="Nome" value={d.nome} onChange={v=>setD({...d,nome:v})}/><Input label="E-mail" value={d.email} onChange={v=>setD({...d,email:v})}/><Input label="Senha" type="password" value={d.senha} onChange={v=>setD({...d,senha:v})}/><Select label="Perfil" value={d.perfil} onChange={v=>setD({...d,perfil:v})} options={["ADMINISTRADOR","SUPERVISOR","INSPETOR","AUDITOR","VISUALIZADOR"]}/><button className="bg-blue-600 text-white px-4 py-2 rounded-lg">Criar usuário</button></form></Modal>}</>
}

function Reports(){
 const types=[["inspecoes","Inspeções"],["auditorias","Auditorias"],["nao-conformidades","Não conformidades"],["acoes-corretivas","Ações corretivas"]];
 async function download(t:string,ext:"pdf"|"excel"){
 const r=await api.get(`/relatorios/${t}/${ext}`,{responseType:"blob"});
 const blob=new Blob([r.data],{type:ext==="pdf"?"application/pdf":"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
 const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=`atlas-${t}.${ext==="pdf"?"pdf":"xlsx"}`; a.click(); URL.revokeObjectURL(a.href);
}
 return <><PageTitle title="Relatórios" subtitle="Consulte e exporte dados do sistema."/><div className="grid md:grid-cols-2 gap-4">{types.map(([id,n])=><div key={id} className="bg-white dark:bg-slate-900 border rounded-xl p-5 flex justify-between items-center"><div><h3 className="font-bold">{n}</h3><p className="text-sm text-slate-500">Dados atualizados do banco.</p></div><div className="flex gap-2"><button onClick={()=>download(id,"pdf")} className="border px-3 py-2 rounded-lg">PDF</button><button onClick={()=>download(id,"excel")} className="border px-3 py-2 rounded-lg">Excel</button></div></div>)}</div><p className="text-xs text-slate-400 mt-5">A exportação JSON é funcional na base. O módulo pode ser conectado a geradores PDF/XLSX no backend sem alterar o banco.</p></>
}

function Notifications(){
 const [d,setD]=useState<any>(null);
 useEffect(()=>{api.get("/dashboard").then(r=>setD(r.data.cards))},[]);
 if(!d)return null;
 const notes=[
   d.ncAbertas>0?`Existem ${d.ncAbertas} não conformidade(s) em aberto.`:null,
   d.acoesAbertas>0?`Existem ${d.acoesAbertas} ação(ões) corretiva(s) pendente(s).`:null,
   d.taxa<90?`A taxa de conformidade está em ${d.taxa}%.`:null
 ].filter(Boolean);
 return <div className="mb-5">{notes.map((n:any)=><div key={n} className="bg-amber-50 border border-amber-200 text-amber-800 rounded-lg p-3 mb-2 flex gap-2"><Clock3 size={18}/>{n}</div>)}</div>
}
function App(){
 const [user,setUser]=useState<User|null>(null);
 useEffect(()=>{const t=localStorage.getItem("atlas_token"),u=localStorage.getItem("atlas_user");if(t&&u)setUser(JSON.parse(u))},[]);
 function logout(){localStorage.clear();setUser(null)}
 if(!user)return <Routes><Route path="*" element={<Login onLogin={setUser}/>}/></Routes>;
 return <Layout user={user} onLogout={logout}><Routes>
  <Route path="/" element={<Dashboard/>}/>
  <Route path="/inspecoes" element={<CrudPage type="inspecoes"/>}/>
  <Route path="/nao-conformidades" element={<CrudPage type="nao-conformidades"/>}/>
  <Route path="/acoes-corretivas" element={<CrudPage type="acoes-corretivas"/>}/>
  <Route path="/auditorias" element={<CrudPage type="auditorias"/>}/>
  <Route path="/documentos" element={<Documents/>}/>
  <Route path="/relatorios" element={<Reports/>}/>
  <Route path="/usuarios" element={<UsersPage/>}/>
  <Route path="/configuracoes" element={<div><PageTitle title="Configurações" subtitle="Parâmetros gerais e preferências do sistema."/><div className="bg-white dark:bg-slate-900 border rounded-xl p-6">Tema, notificações, senha, dados da empresa e backup podem ser configurados nesta área.</div></div>}/>
  <Route path="*" element={<Navigate to="/" replace/>}/>
 </Routes></Layout>
}
export default App;
