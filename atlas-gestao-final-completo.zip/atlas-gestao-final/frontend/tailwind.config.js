/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      fontFamily: { sans: ["Inter", "sans-serif"], heading: ["Poppins", "sans-serif"] },
      colors: {
        primary: "#2563EB",
        success: "#22C55E",
        danger: "#EF4444",
        warning: "#F59E0B"
      }
    }
  },
  plugins: []
};
