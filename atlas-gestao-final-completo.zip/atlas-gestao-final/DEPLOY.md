# Atlas Gestão — Implantação

## Local
1. Instale Node.js 20+ e Docker.
2. `docker compose up -d`
3. `cd backend && npm install && npx prisma generate && npx prisma migrate dev --name init && npm run seed && npm run dev`
4. Em outro terminal: `cd frontend && npm install && npm run dev`

## GitHub
```bash
git init
git add .
git commit -m "Atlas Gestão completo"
git branch -M main
git remote add origin SEU_REPOSITORIO
git push -u origin main
```

## Produção
Defina `DATABASE_URL`, `JWT_SECRET`, `CORS_ORIGIN` e `UPLOAD_DIR` no backend.
Use PostgreSQL gerenciado e HTTPS.
Não mantenha a senha do administrador inicial em produção.
