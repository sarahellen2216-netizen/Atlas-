# Atlas Gestão
Sistema de Garantia da Qualidade — Gestão Inteligente da Qualidade para Empresas Modernas.

## Stack
- Frontend: React + TypeScript + Vite + Tailwind CSS + React Router
- Backend: Node.js + Express + TypeScript + Prisma + JWT + Multer
- Banco: PostgreSQL
- Relatórios: PDF/Excel preparados para extensão
- Autenticação e perfis de acesso

## Estrutura
- `frontend/` interface web
- `backend/` API REST
- `backend/prisma/schema.prisma` modelo PostgreSQL
- `docker-compose.yml` PostgreSQL

## Como executar

### 1. Banco
Tenha Docker instalado e rode:

```bash
docker compose up -d
```

### 2. Backend
```bash
cd backend
cp .env.example .env
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run seed
npm run dev
```

API: `http://localhost:3333`

Usuário inicial:
- E-mail: `admin@atlasgestao.com`
- Senha: `Admin@123`

### 3. Frontend
Em outro terminal:

```bash
cd frontend
npm install
npm run dev
```

Acesse `http://localhost:5173`.

> Troque a senha do usuário administrador em um ambiente real.


## Recursos adicionais desta versão
- Exportação nativa em PDF.
- Exportação nativa em Excel/XLSX.
- Centro de alertas no dashboard para NCs, ações e taxa de conformidade.
- Upload de documentos e histórico de revisões.
- CRUD completo para os principais módulos.
- Indicadores e dados agregados do PostgreSQL.
